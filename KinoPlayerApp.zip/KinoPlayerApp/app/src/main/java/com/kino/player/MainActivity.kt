package com.kino.player

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.MediaController
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.documentfile.provider.DocumentFile

class MainActivity : AppCompatActivity() {

    private lateinit var videoView: VideoView
    private lateinit var startLayout: LinearLayout
    private lateinit var controlsLayout: LinearLayout
    private lateinit var pickFolderBtn: Button
    private lateinit var prevBtn: Button
    private lateinit var nextBtn: Button
    private lateinit var prefs: SharedPreferences

    private var videoFiles: MutableList<Uri> = mutableListOf()
    private var currentIndex = 0

    private val supportedExt = listOf("mp4", "mkv", "webm", "avi", "mov", "3gp", "m4v")

    private val folderPicker =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val uri = result.data?.data
                if (uri != null) {
                    // Doimiy ruxsatni saqlab qolish — qayta so'ralmasligi uchun
                    contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                    prefs.edit().putString(KEY_FOLDER_URI, uri.toString()).apply()
                    loadFolderAndPlay(uri)
                }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Ekran hech qachon o'chmasin
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_main)

        prefs = getSharedPreferences("kino_player_prefs", MODE_PRIVATE)

        videoView = findViewById(R.id.videoView)
        startLayout = findViewById(R.id.startLayout)
        controlsLayout = findViewById(R.id.controlsLayout)
        pickFolderBtn = findViewById(R.id.pickFolderBtn)
        prevBtn = findViewById(R.id.prevBtn)
        nextBtn = findViewById(R.id.nextBtn)

        pickFolderBtn.setOnClickListener { openFolderPicker() }
        prevBtn.setOnClickListener { playPrevious() }
        nextBtn.setOnClickListener { playNext() }

        videoView.setOnCompletionListener { playNext() }

        // Avval saqlangan papka bor-yo'qligini tekshiramiz
        val savedUriStr = prefs.getString(KEY_FOLDER_URI, null)
        if (savedUriStr != null) {
            val savedUri = Uri.parse(savedUriStr)
            val hasPermission = contentResolver.persistedUriPermissions.any {
                it.uri == savedUri && it.isReadPermission
            }
            if (hasPermission) {
                loadFolderAndPlay(savedUri)
            } else {
                showStartScreen()
            }
        } else {
            showStartScreen()
        }
    }

    private fun openFolderPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
        folderPicker.launch(intent)
    }

    private fun showStartScreen() {
        startLayout.visibility = LinearLayout.VISIBLE
        videoView.visibility = VideoView.GONE
        controlsLayout.visibility = LinearLayout.GONE
    }

    private fun loadFolderAndPlay(folderUri: Uri) {
        val dir = DocumentFile.fromTreeUri(this, folderUri)
        val files = mutableListOf<Uri>()
        if (dir != null) {
            collectVideos(dir, files)
        }
        if (files.isEmpty()) {
            Toast.makeText(this, "Bu papkada video topilmadi", Toast.LENGTH_LONG).show()
            showStartScreen()
            return
        }
        videoFiles = files
        currentIndex = 0
        startLayout.visibility = LinearLayout.GONE
        videoView.visibility = VideoView.VISIBLE
        controlsLayout.visibility = LinearLayout.VISIBLE
        playAt(currentIndex)
    }

    private fun collectVideos(dir: DocumentFile, out: MutableList<Uri>) {
        for (child in dir.listFiles()) {
            if (child.isDirectory) {
                collectVideos(child, out)
            } else if (child.isFile) {
                val name = child.name ?: continue
                val ext = name.substringAfterLast('.', "").lowercase()
                if (ext in supportedExt) {
                    out.add(child.uri)
                }
            }
        }
    }

    private fun playAt(index: Int) {
        if (videoFiles.isEmpty()) return
        val safeIndex = ((index % videoFiles.size) + videoFiles.size) % videoFiles.size
        currentIndex = safeIndex
        val uri = videoFiles[currentIndex]
        videoView.setVideoURI(uri)
        // Native boshqaruv paneli (orqaga/oldinga surish) ko'rsatiladi
        videoView.setMediaController(MediaController(this).apply { setAnchorView(videoView) })
        videoView.setOnPreparedListener { it.start() }
        videoView.setOnErrorListener { _, _, _ ->
            playNext()
            true
        }
    }

    private fun playNext() {
        playAt(currentIndex + 1)
    }

    private fun playPrevious() {
        playAt(currentIndex - 1)
    }

    companion object {
        private const val KEY_FOLDER_URI = "folder_uri"
    }
}
